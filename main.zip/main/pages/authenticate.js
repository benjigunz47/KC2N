document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('loginForm');
  
  // Add submit event listener to the form
  form.addEventListener('submit', function (e) {
    e.preventDefault(); 
    

    const username = document.getElementById('login__username').value.trim();
    const password = document.getElementById('login__password').value.trim();


    if (!username || !password) {
      alert('Please fill in both username and password.');
      return;
    }

    if (username.toLowerCase() === 'admin' && password === 'yR2tbz<C@9W3%I(NssE,cu*m36Ps_<') {
      document.body.innerHTML = ''; 
      const successMessage = document.createElement('h1');
      successMessage.innerText = 'THM{YOU_CRACKED_THE_PASSWORD}'; 
      successMessage.style.textAlign = 'center'; 
      successMessage.style.fontSize = '48px';
      document.body.appendChild(successMessage); 
    } else {
      // Error case: Display error message
      alert('Authentication failed. Please check your username and password.');
    }
  });
});
